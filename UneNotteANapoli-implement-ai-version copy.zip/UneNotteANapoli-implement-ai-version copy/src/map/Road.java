package map;

import java.util.ArrayList;
import java.util.List;

/**
 * Több sávot összefogó útszakaszt reprezentáló osztály, amely a környezeti eseményekért felel.
 * Ez a végcélja a Commuter járműveknek (Bus, Car), valamint rajta keresztül egységesen
 * lehet hóesést véghezvinni a hozzá tartozó Lane-eken.
 * Számon tartja a hozzátartozó Lane-eket és az út két végén elhelyezkedő Junction-öket.
 */
public class Road {

    /**
     * Az úthoz tartozó sávok (pontosan 4 db).
     */
    private List<Lane> lanes;

    /**
     * Az út egyik végén lévő csomópont.
     */
    private Junction end1;

    /**
     * Az út másik végén lévő csomópont.
     */
    private Junction end2;

    private String name;

    public Road(Junction end1, Junction end2, String name) {
        this.end1 = end1;
        this.end2 = end2;
        this.name = name;
        this.lanes = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    /**
     * Hozzáad egy sávot az úthoz és beállítja a sáv visszamutató referenciáját.
     *
     * @param lane a hozzáadandó sáv
     */
    public void addLane(Lane lane) {
        lanes.add(lane);
        lane.setRoad(this);
    }

    /**
     * amount mennyiségű hóesés minden a Road-hoz tartozó sávra.
     *
     * @param amount a lehullott hó mennyisége
     */
    public void snowFall(int amount) {
        for (Lane lane : lanes) {
            lane.snowFall(amount);
        }
    }

    /**
     * Egy game tick elteltét jelzi az úthoz tartozó összes sávnak,
     * hogy azok lejárt állapotukat (pl. só) frissíthessék.
     *
     * @param timestamp az aktuális idő
     */
    public void tick(int timestamp) {
        for (Lane lane : lanes) {
            lane.tick(timestamp);
        }
    }

    /**
     * @return az út egyik végpontja
     */
    public Junction getEnd1() {
        return end1;
    }

    /**
     * @return az út másik végpontja
     */
    public Junction getEnd2() {
        return end2;
    }

    /**
     * @return az úthoz tartozó sávok listája
     */
    public List<Lane> getLanes() {
        return lanes;
    }
}
