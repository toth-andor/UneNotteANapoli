Szekvencia diagramok ide
